import React, { useEffect, useState } from "react";
import {
	BrowserRouter as Router,
	Routes,
	Route,
	Navigate,
} from "react-router-dom";
import axios from "axios";
import DashboardLayout from "./components/DashboardLayout";
import Users from "./components/Users";
import Channels from "./components/Channels";
import VisitorStats from "./components/VisitorStats";
import Login from "./components/Login";

const App = () => {
	const [isAuthenticated, setIsAuthenticated] = useState(false);
	const [loading, setLoading] = useState(true);

	useEffect(() => {
		const checkAuthStatus = async () => {
			try {
				const response = await axios.get("http://localhost:3002/check-auth", {
					withCredentials: true,
				});
				if (response.status === 200 && response.data.isAuthenticated) {
					setIsAuthenticated(true);
				} else {
					setIsAuthenticated(false);
				}
			} catch (error) {
				setIsAuthenticated(false);
			} finally {
				setLoading(false);
			}
		};

		checkAuthStatus();
	}, []);

	if (loading) {
		return <div>Loading...</div>;
	}

	return (
		<Router>
			<Routes>
				<Route path="/" element={<Navigate to="/admin" />} />
				<Route path="/login" element={<Login />} />
				<Route
					path="/admin"
					element={
						isAuthenticated ? <DashboardLayout /> : <Navigate to="/login" />
					}
				>
					<Route path="users" element={<Users />} />
					<Route path="channels" element={<Channels />} />
					<Route path="visitor-stats" element={<VisitorStats />} />
				</Route>
			</Routes>
		</Router>
	);
};

export default App;