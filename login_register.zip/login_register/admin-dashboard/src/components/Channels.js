import React, { useEffect, useState } from "react";
import axios from "axios";

const Channels = () => {
	const [channels, setChannels] = useState([]);

	useEffect(() => {
		axios
			.get("http://localhost:3002/channels")
			.then((response) => setChannels(response.data.channels))
			.catch((error) => console.error("Error fetching channels:", error));
	}, []);

	return (
		<div>
			<h2 className="text-2xl font-bold mb-4">Channels</h2>
			<table className="min-w-full bg-white">
				<thead>
					<tr>
						<th className="py-2 px-4 border-b">Name</th>
						<th className="py-2 px-4 border-b">Visitor Count</th>
					</tr>
				</thead>
				<tbody>
					{channels.map((channel) => (
						<tr key={channel._id} className="text-center">
							<td className="py-2 px-4 border-b">{channel.name}</td>
							<td className="py-2 px-4 border-b">{channel.visitorCount}</td>
						</tr>
					))}
				</tbody>
			</table>
		</div>
	);
};

export default Channels;
