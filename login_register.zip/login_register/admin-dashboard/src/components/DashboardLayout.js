import React from "react";
import { Link, Outlet } from "react-router-dom";

const DashboardLayout = () => {
	return (
		<div className="min-h-screen flex">
			<aside className="w-64 bg-gray-800 text-white">
				<div className="p-4">
					<h2 className="text-2xl font-bold">Admin Dashboard</h2>
				</div>
				<nav className="mt-4">
					<Link to="/admin/users" className="block py-2 px-4 hover:bg-gray-700">
						Users
					</Link>
					<Link
						to="/admin/channels"
						className="block py-2 px-4 hover:bg-gray-700"
					>
						Channels
					</Link>
					<Link
						to="/admin/visitor-stats"
						className="block py-2 px-4 hover:bg-gray-700"
					>
						Visitor Stats
					</Link>
				</nav>
			</aside>
			<main className="flex-1 p-6 bg-gray-100">
				<Outlet />
			</main>
		</div>
	);
};

export default DashboardLayout;
