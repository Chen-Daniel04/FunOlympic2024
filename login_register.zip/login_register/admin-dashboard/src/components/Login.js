import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Login = () => {
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");
	const [error, setError] = useState("");
	const navigate = useNavigate();

	const handleSubmit = async (e) => {
		e.preventDefault();

		try {
			const response = await axios.post(
				"http://localhost:3002/login",
				{ email, password },
				{ withCredentials: true }
			);
			if (response.status === 200 && response.data.Status === "Success") {
				console.log("Login successful:", response.data);
				navigate("/admin");
			} else {
				console.log("Login failed:", response.data);
				setError("Invalid credentials");
			}
		} catch (error) {
			console.error("Login error:", error);
			setError("Invalid credentials");
		}
	};

	return (
		<div className="min-h-screen flex justify-center items-center bg-gray-100">
			<div className="bg-white p-8 rounded-lg shadow-lg max-w-md w-full">
				<h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">
					Admin Login
				</h2>
				<form onSubmit={handleSubmit}>
					<div className="mb-4">
						<label htmlFor="email" className="block text-gray-700 mb-2">
							<strong>Email</strong>
						</label>
						<input
							type="email"
							placeholder="Enter Email"
							autoComplete="off"
							name="email"
							className="form-input mt-1 block w-full"
							value={email}
							onChange={(e) => setEmail(e.target.value)}
						/>
					</div>
					<div className="mb-4">
						<label htmlFor="password" className="block text-gray-700 mb-2">
							<strong>Password</strong>
						</label>
						<input
							type="password"
							placeholder="Enter Password"
							name="password"
							className="form-input mt-1 block w-full"
							value={password}
							onChange={(e) => setPassword(e.target.value)}
						/>
					</div>
					{error && <p className="text-red-500 text-sm mb-4">{error}</p>}
					<button
						type="submit"
						className="bg-blue-500 text-white py-2 px-4 rounded w-full hover:bg-blue-600 transition duration-300"
					>
						Login
					</button>
				</form>
			</div>
		</div>
	);
};

export default Login;