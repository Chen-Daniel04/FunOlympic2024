import React, { useEffect, useState } from "react";
import axios from "axios";

const Users = () => {
	const [users, setUsers] = useState([]);
	const [editingUser, setEditingUser] = useState(null);
	const [newPassword, setNewPassword] = useState("");

	useEffect(() => {
		fetchUsers();
	}, []);

	const fetchUsers = async () => {
		try {
			const response = await axios.get("http://localhost:3002/users", { withCredentials: true });
			setUsers(response.data);
		} catch (error) {
			console.error("Error fetching users:", error);
		}
	};

	const handleEdit = (user) => {
		setEditingUser(user);
	};

	const handleDelete = async (userId) => {
		try {
			await axios.delete(`http://localhost:3002/users/${userId}`, { withCredentials: true });
			fetchUsers();
		} catch (error) {
			console.error("Error deleting user:", error);
		}
	};

	const handleUpdate = async () => {
		try {
			const { _id, name, email, role, sportChannels } = editingUser;
			await axios.put(`http://localhost:3002/users/${_id}`, { name, email, role, sportChannels }, { withCredentials: true });
			setEditingUser(null);
			fetchUsers();
		} catch (error) {
			console.error("Error updating user:", error);
		}
	};

	const handleResetPassword = async () => {
		try {
			await axios.post(`http://localhost:3002/users/${editingUser._id}/reset-password`, { newPassword }, { withCredentials: true });
			setNewPassword("");
			alert("Password reset successfully");
		} catch (error) {
			console.error("Error resetting password:", error);
		}
	};

	return (
		<div>
			<h2 className="text-2xl font-bold mb-4">Users</h2>
			<table className="min-w-full bg-white">
				<thead>
					<tr>
						<th className="py-2 px-4 border-b">Name</th>
						<th className="py-2 px-4 border-b">Email</th>
						<th className="py-2 px-4 border-b">Role</th>
						<th className="py-2 px-4 border-b">Sport Channels</th>
						<th className="py-2 px-4 border-b">Actions</th>
					</tr>
				</thead>
				<tbody>
					{users.map((user) => (
						<tr key={user._id} className="text-center">
							<td className="py-2 px-4 border-b">{user.name}</td>
							<td className="py-2 px-4 border-b">{user.email}</td>
							<td className="py-2 px-4 border-b">{user.role}</td>
							<td className="py-2 px-4 border-b">{user.sportChannels?.join(", ") || "None"}</td>
							<td className="py-2 px-4 border-b">
								<button onClick={() => handleEdit(user)} className="bg-yellow-500 text-white py-1 px-3 rounded mr-2">Edit</button>
								<button onClick={() => handleDelete(user._id)} className="bg-red-500 text-white py-1 px-3 rounded">Delete</button>
							</td>
						</tr>
					))}
				</tbody>
			</table>

			{editingUser && (
				<div className="mt-6">
					<h3 className="text-xl font-bold mb-4">Edit User</h3>
					<input
						type="text"
						placeholder="Name"
						value={editingUser.name}
						onChange={(e) => setEditingUser({ ...editingUser, name: e.target.value })}
						className="form-input mt-1 block w-full mb-4"
					/>
					<input
						type="email"
						placeholder="Email"
						value={editingUser.email}
						onChange={(e) => setEditingUser({ ...editingUser, email: e.target.value })}
						className="form-input mt-1 block w-full mb-4"
					/>
					<input
						type="text"
						placeholder="Role"
						value={editingUser.role}
						onChange={(e) => setEditingUser({ ...editingUser, role: e.target.value })}
						className="form-input mt-1 block w-full mb-4"
					/>
					<input
						type="text"
						placeholder="Sport Channels"
						value={editingUser.sportChannels.join(", ")}
						onChange={(e) => setEditingUser({ ...editingUser, sportChannels: e.target.value.split(", ") })}
						className="form-input mt-1 block w-full mb-4"
					/>
					<button onClick={handleUpdate} className="bg-blue-500 text-white py-2 px-4 rounded">Update</button>
				</div>
			)}

			{editingUser && (
				<div className="mt-6">
					<h3 className="text-xl font-bold mb-4">Reset Password for {editingUser.name}</h3>
					<input
						type="password"
						placeholder="New Password"
						value={newPassword}
						onChange={(e) => setNewPassword(e.target.value)}
						className="form-input mt-1 block w-full mb-4"
					/>
					<button onClick={handleResetPassword} className="bg-blue-500 text-white py-2 px-4 rounded">Reset Password</button>
				</div>
			)}
		</div>
	);
};

export default Users;