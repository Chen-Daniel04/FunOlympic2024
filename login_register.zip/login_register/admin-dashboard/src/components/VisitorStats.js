import React, { useEffect, useState } from "react";
import axios from "axios";

const VisitorStats = () => {
	const [stats, setStats] = useState([]);

	useEffect(() => {
		axios
			.get("http://localhost:3002/channels")
			.then((response) => setStats(response.data.channels))
			.catch((error) => console.error("Error fetching visitor stats:", error));
	}, []);

	return (
		<div>
			<h2 className="text-2xl font-bold mb-4">Visitor Stats</h2>
			<table className="min-w-full bg-white">
				<thead>
					<tr>
						<th className="py-2 px-4 border-b">Channel</th>
						<th className="py-2 px-4 border-b">Visitor Count</th>
					</tr>
				</thead>
				<tbody>
					{stats.map((stat) => (
						<tr key={stat._id} className="text-center">
							<td className="py-2 px-4 border-b">{stat.name}</td>
							<td className="py-2 px-4 border-b">{stat.visitorCount}</td>
						</tr>
					))}
				</tbody>
			</table>
		</div>
	);
};

export default VisitorStats;
