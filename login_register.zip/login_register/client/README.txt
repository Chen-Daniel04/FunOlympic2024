# React + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react/README.md) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh

Front-End App
1: npm init vite
2: then enter project name
3: then select React
4: select JavaScript
5. cd to the project folder
6: npm install
7: npm run dev

8: lastly run: npm install axios bootstrap

Server-side App:
1: npm init -y
2: npm install express mongoose cors nodemon cookie-parser
               bcrypt jsonwebtoken nodemailer qrcode speakeasy
3: create a file inside the folder and write the code there
4: cd Server
5: 'npm start' for start running Server on Port 3002

Database:
1: Must install MongoDB Compass
2: Necessary to create 'employee' with the collection name of 'users'
    MONGODB_URI= mongodb://127.0.0.1:27017/employee from '.env' file

Example Data Format:
[{
  "_id": {
    "$oid": "65b94c4e038eaee713eb3524"
  },
  "name": "Daniel12",
  "email": "yoye7198@gmail.com",
  "password": "$2b$10$fFFct3XUhBX8zammp.aIFORrtxHi/VBR9RpxXM5.ymh1StzpyIO/W",
  "role": "visitor",
  "otp": "408559",
  "secretKey": {
    "ascii": "z:&ca{.8R}@XNO6i!aWi",
    "hex": "7a3a2663617b2e38527d40584e4f366921615769",
    "base32": "PI5CMY3BPMXDQUT5IBME4TZWNEQWCV3J",
    "otpauth_url": "otpauth://totp/SecretKey?secret=PI5CMY3BPMXDQUT5IBME4TZWNEQWCV3J"
  },
  "__v": 0
}]

External Service:
1: Necessary to install 'Authenticator' app on mobiles for verifying and scanning QR 

