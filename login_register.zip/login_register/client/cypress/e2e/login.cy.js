describe("Client Login", () => {
	beforeEach(() => {
		cy.visit("http://localhost:5173/login"); // Adjust the URL as necessary
	});

	it("should show an error for invalid email format", () => {
		cy.get('input[name="email"]').type("invalid-email");
		cy.get('input[name="password"]').type("password");
		cy.get('button[type="submit"]').click();

		cy.contains("Please enter a valid email address.").should("be.visible");
	});

	it("should login and request OTP for valid credentials", () => {
		cy.intercept("POST", "http://localhost:3002/login", {
			statusCode: 200,
			body: { Status: "Success" },
		});

		cy.intercept("POST", "http://localhost:3002/get-otp", {
			statusCode: 200,
		});

		cy.get('input[name="email"]').type("user@example.com");
		cy.get('input[name="password"]').type("password");
		cy.get('button[type="submit"]').click();

		cy.contains("OTP").should("be.visible");
	});

	it("should verify OTP and navigate to QR verification", () => {
		cy.intercept("POST", "http://localhost:3002/verify-otp", {
			statusCode: 200,
			body: { verified: true },
		});

		cy.get('input[name="email"]').type("user@example.com");
		cy.get('input[name="password"]').type("password");
		cy.get('button[type="submit"]').click();

		cy.get('input[name="otp"]').type("123456");
		cy.get("button").contains("Verify OTP").click();

		cy.url().should("include", "/qr-verification");
	});

	it("should show error for invalid OTP", () => {
		cy.intercept("POST", "http://localhost:3002/verify-otp", {
			statusCode: 401,
			body: { verified: false },
		});

		cy.get('input[name="email"]').type("user@example.com");
		cy.get('input[name="password"]').type("password");
		cy.get('button[type="submit"]').click();

		cy.get('input[name="otp"]').type("123456");
		cy.get("button").contains("Verify OTP").click();

		cy.contains("OTP verification failed").should("be.visible");
	});
});
