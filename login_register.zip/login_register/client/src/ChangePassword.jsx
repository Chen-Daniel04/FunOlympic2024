import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';

function ChangePassword() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [formError, setFormError] = useState('');
  const [passwordMatchError, setPasswordMatchError] = useState('');
  const [passwordStrength, setPasswordStrength] = useState(0);
  const [showPassword, setShowPassword] = useState(false); // Added state for Show Password
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!email || !password || !newPassword) {
      setFormError('Please fill out all fields.');
      return;
    }

    // Check if the new password is the same as the old password
    if (newPassword === password) {
      setPasswordMatchError('New password cannot be the same as the old password.');
      return;
    }

    axios
      .post('http://localhost:3002/change-password', {
        email,
        password,
        newpassword: newPassword,
      })
      .then((res) => {
        navigate('/login'); // Redirect to login page on success
      })
      .catch((err) => {
        console.log(err);
        setFormError('Error changing password. Please check your credentials.');
      });
  };

  const handlePasswordChange = (e) => {
    const newPassword = e.target.value;

    // Check if the new password is the same as the old password
    if (newPassword === password) {
      setPasswordMatchError('New password cannot be the same as the old password.');
    } else {
      setPasswordMatchError('');
    }

    // Simple password strength measurement
    const lengthScore = Math.min(newPassword.length / 8, 1);
    const uppercaseScore = /[A-Z]/.test(newPassword) ? 1 : 0;
    const digitScore = /\d/.test(newPassword) ? 1 : 0;
    const specialCharScore = /[!@#$%^&*]/.test(newPassword) ? 1 : 0;

    const totalScore = lengthScore + uppercaseScore + digitScore + specialCharScore;
    setPasswordStrength(totalScore);

    setNewPassword(newPassword);
  };

  const toggleShowPassword = () => {
    setShowPassword(!showPassword);
  };

  return (
    <div className="d-flex justify-content-center align-items-center bg-secondary vh-100">
      <div className="bg-white p-3 rounded w-25">
        <h2>Change Password</h2>
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label htmlFor="email">
              <strong>Email</strong>
            </label>
            <input
              type="email"
              placeholder="Enter Email"
              autoComplete="off"
              name="email"
              className="form-control rounded-0"
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div className="mb-3">
            <label htmlFor="password">
              <strong>Current Password</strong>
            </label>
            <input
              type={showPassword ? 'text' : 'password'} 
              placeholder="Enter Current Password"
              name="password"
              className="form-control rounded-0"
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <div className="mb-3">
            <label htmlFor="newPassword">
              <strong>New Password</strong>
            </label>
            <input
              type={showPassword ? 'text' : 'password'} 
              placeholder="Enter New Password"
              name="newPassword"
              className="form-control rounded-0"
              onChange={handlePasswordChange}
            />
            {passwordMatchError && <small className="text-danger">{passwordMatchError}</small>}
          </div>
          <div className="mb-3">
            <div>
              <strong>Password Strength:</strong>
            </div>
            <div className="progress">
              <div
                className={`progress-bar bg-${getProgressBarColor(passwordStrength)}`}
                role="progressbar"
                style={{ width: `${passwordStrength * 25}%` }}
                aria-valuenow={passwordStrength * 25}
                aria-valuemin="0"
                aria-valuemax="100"
              ></div>
            </div>
          </div>
          <div className="mb-3 form-check">
            <input
              type="checkbox"
              className="form-check-input"
              id="showPasswordCheckbox"
              onChange={toggleShowPassword}
            />
            <label className="form-check-label" htmlFor="showPasswordCheckbox">
              Show Password
            </label>
          </div>
          {formError && <small className="text-danger">{formError}</small>}
          <button type="submit" className="btn btn-success w-100 rounded-0">
            Change Password
          </button>
        </form>
        <p>Remember your password? </p>
        <Link
          to="/login"
          className="btn btn-default border w-100 bg-light rounded-0 text-decoration-none"
        >
          Login
        </Link>
      </div>
    </div>
  );
}

const getProgressBarColor = (score) => {
  if (score < 1) {
    return 'danger';
  } else if (score < 2) {
    return 'warning';
  } else if (score < 3) {
    return 'info';
  } else {
    return 'success';
  }
};

export default ChangePassword;
