import axios from "axios";
import React from "react";
import { useNavigate } from "react-router-dom";
import TennisImg from "./assets/images/Tennis.jpg";
import BasketBallImg from "./assets/images/basketball.png";
import BoxingImg from "./assets/images/boxing.png";
import CricketImg from "./assets/images/cricket.png";
import FootballImg from "./assets/images/football.jpg";
import MMAImg from "./assets/images/mma.png";
import VolleyBallImg from "./assets/images/volleyball.png";

function Home() {
  const navigate = useNavigate();

  const Logout = () => {
    axios
      .post("http://localhost:3002/logout", {}, { withCredentials: true })
      .then(() => {
        navigate("/login");
      })
      .catch((error) => {
        console.error("Error logging out:", error);
      });
  };

  const ChangePassword = () => {
    navigate("/changepassword");
  };

  const viewDetails = () => {
    navigate("/user-details");
  };

  const channelClickHandler = (to, channel) => {
    window.open(to, "_blank");
    axios.post("http://localhost:3002/increase-visitor-count", {
      channel: channel,
    });
  };

  const channels = [
    {
      name: "Football",
      image: FootballImg,
      to: "https://www.livesporttv.com/soccer/matches/",
    },
    {
      name: "BasketBall",
      image: BasketBallImg,
      to: "https://www.livesporttv.com/basketball/matches/",
    },
    {
      name: "Tennis",
      image: TennisImg,
      to: "https://www.livesporttv.com/tennis/matches/",
    },
    {
      name: "Boxing",
      image: BoxingImg,
      to: "https://www.livesporttv.com/boxing/matches/",
    },
    {
      name: "VolleyBall",
      image: VolleyBallImg,
      to: "https://www.livesporttv.com/volleyball/matches/",
    },
    {
      name: "Cricket",
      image: CricketImg,
      to: "https://www.livesporttv.com/cricket/matches/",
    },
    {
      name: "MMA",
      image: MMAImg,
      to: "https://www.livesporttv.com/mma/matches/",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500">
      <div className="w-full flex justify-between items-center p-6 bg-white shadow-md sticky top-0">
        <h1 className="text-3xl font-bold text-gray-800">Home Page</h1>
        <div className="flex gap-4">
          <button
            type="button"
            onClick={viewDetails}
            className="border-2 border-gray-800 px-5 py-2 rounded-full bg-transparent hover:bg-gray-200 transition duration-300"
          >
            View Details
          </button>
          <button
            type="button"
            onClick={ChangePassword}
            className="border-2 border-gray-800 px-5 py-2 rounded-full bg-transparent hover:bg-gray-200 transition duration-300"
          >
            Change Password
          </button>
          <button
            type="button"
            className="border-2 border-gray-800 px-5 py-2 rounded-full hover:bg-gray-800 hover:text-white bg-transparent transition duration-300"
            onClick={Logout}
          >
            Logout
          </button>
        </div>
      </div>

      <div className="container mx-auto py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {channels.map((channel) => (
            <div
              onClick={() => channelClickHandler(channel.to, channel.name)}
              key={channel.name}
              className="flex flex-col items-center bg-white shadow-lg hover:shadow-xl transition duration-300 rounded-lg overflow-hidden cursor-pointer"
            >
              <img
                src={channel.image}
                alt={channel.name}
                className="w-full h-48 object-cover"
              />
              <p className="font-semibold text-xl text-gray-800 py-4">
                {channel.name}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Home;
