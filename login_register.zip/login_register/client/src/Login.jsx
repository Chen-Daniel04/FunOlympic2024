import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showOTP, setShowOTP] = useState(false);
  const [otp, setOTP] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [emailError, setEmailError] = useState("");
  const navigate = useNavigate();

  axios.defaults.withCredentials = true;

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!isValidEmail(email)) {
      setEmailError("Please enter a valid email address.");
      return;
    }

    setEmailError("");

    try {
      const res = await axios.post("http://localhost:3002/login", {
        email,
        password,
      });
      if (res.data.Status === "Success") {
        await getOTP();
      }
    } catch (err) {
      console.log(err);
    }
  };

  const getOTP = async () => {
    try {
      await axios.post("http://localhost:3002/get-otp", { email });
      setShowOTP(true);
    } catch (error) {
      console.log(error);
    }
  };

  const verifyOTP = async () => {
    try {
      const response = await axios.post("http://localhost:3002/verify-otp", {
        email,
        otp,
      });
      if (response.data.verified) {
        navigate("/qr-verification", { state: { email } });
      } else {
        console.log("OTP verification failed");
      }
    } catch (error) {
      console.log(error);
    }
  };

  const isValidEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  return (
    <div className="flex justify-center items-center bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 min-h-screen">
      <div className="bg-white p-8 rounded-lg shadow-lg max-w-md w-full">
        <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">
          Login
        </h2>
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label htmlFor="email" className="block text-gray-700 mb-2">
              <strong>Email</strong>
            </label>
            <input
              type="email"
              placeholder="Enter Email"
              autoComplete="off"
              name="email"
              className={`form-input mt-1 block w-full ${
                emailError ? "border-red-500" : ""
              }`}
              onChange={(e) => setEmail(e.target.value)}
            />
            {emailError && (
              <p className="text-red-500 text-sm mt-2">{emailError}</p>
            )}
          </div>
          <div className="mb-4">
            <label htmlFor="password" className="block text-gray-700 mb-2">
              <strong>Password</strong>
            </label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                placeholder="Enter Password"
                name="password"
                className="form-input mt-1 block w-full"
                onChange={(e) => setPassword(e.target.value)}
              />
              <button
                type="button"
                className="absolute inset-y-0 right-0 px-3 py-2 text-gray-600"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? "Hide" : "Show"}
              </button>
            </div>
          </div>
          <button
            type="submit"
            className="bg-blue-500 text-white py-2 px-4 rounded w-full hover:bg-blue-600 transition duration-300"
            disabled={showOTP}
          >
            Login
          </button>
        </form>
        {showOTP && (
          <div className="mt-4">
            <label className="block text-gray-700 mb-2">
              <strong>OTP</strong>
            </label>
            <div className="flex items-center">
              <input
                type="number"
                placeholder="Enter OTP you received on your email"
                name="otp"
                className="form-input mt-1 block w-2/3"
                onChange={(e) => setOTP(e.target.value)}
              />
              <button
                className="bg-green-500 text-white py-2 px-4 rounded ml-2 hover:bg-green-600 transition duration-300"
                onClick={verifyOTP}
              >
                Verify OTP
              </button>
            </div>
          </div>
        )}
        <p className="mt-4 text-center">
          Forgot your password?
          <br />
          <Link to="/forgot-password" className="text-blue-500 hover:underline">
            Forgot Password
          </Link>
        </p>
        <Link
          to="/register"
          className="block text-center bg-gray-100 text-gray-700 py-2 px-4 rounded mt-4 hover:bg-gray-200 transition duration-300"
        >
          Sign Up
        </Link>
      </div>
    </div>
  );
}

export default Login;
