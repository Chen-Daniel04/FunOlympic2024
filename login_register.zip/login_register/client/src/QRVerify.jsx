import React, { useEffect, useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import axios from "axios";

function QRVerify() {
  const [qrURL, setQRURL] = useState("");
  const [showOTP, setShowOTP] = useState(false);
  const [otp, setOTP] = useState("");
  const navigate = useNavigate();
  const location = useLocation();

  axios.defaults.withCredentials = true;

  useEffect(() => {
    getQR();
  }, []);

  const getQR = async () => {
    try {
      const res = await axios.post(`http://localhost:3002/generate-qr`, {
        email: location.state.email,
      });
      setQRURL(res.data.qrURL);
      setShowOTP(true);
    } catch (error) {
      console.log(error);
    }
  };

  const verifyToken = async () => {
    try {
      const res = await axios.post("http://localhost:3002/verify-qr", {
        token: otp,
        email: location.state.email,
      });
      if (res.status === 200) {
        if (res.data.role === "admin") {
          navigate("/dashboard");
        } else {
          navigate("/home", { state: { email: location.state.email } });
        }
      }
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div className="flex justify-center items-center bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 min-h-screen">
      <div className="bg-white p-8 rounded-lg shadow-lg max-w-md w-full text-center">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">
          QR Verification
        </h2>
        {qrURL && (
          <div className="flex flex-col items-center gap-4">
            <img src={qrURL} alt="QR Code" className="w-48 h-48" />
            <input
              type="text"
              className="form-input mt-1 block w-full"
              value={otp}
              onChange={(e) => setOTP(e.target.value)}
              placeholder="Enter your OTP"
            />
            <button
              className="bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600 transition duration-300"
              onClick={verifyToken}
            >
              Verify
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default QRVerify;
