import React, { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import axios from 'axios';

function ResetPassword() {
  const [password, setPassword] = useState('');
  const [passwordStrength, setPasswordStrength] = useState(0);
  const [formError, setFormError] = useState('');
  const navigate = useNavigate();
  const { id, token } = useParams();

  axios.defaults.withCredentials = true;

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!password) {
      setFormError("Please enter a new password.");
      return;
    }

    axios
      .post(`http://localhost:3002/reset-password/${id}/${token}`, { password })
      .then((res) => {
        if (res.data.Status === 'Success') {
          navigate('/login');
        }
      })
      .catch((err) => {
        console.log(err);
        setFormError("Error updating password. Please check your credentials. Also cannot update old password!");
      });
  };

  const handlePasswordChange = (e) => {
    const newPassword = e.target.value;

    // Simple password strength measurement
    const lengthScore = Math.min(newPassword.length / 8, 1);
    const uppercaseScore = /[A-Z]/.test(newPassword) ? 1 : 0;
    const digitScore = /\d/.test(newPassword) ? 1 : 0;
    const specialCharScore = /[!@#$%^&*]/.test(newPassword) ? 1 : 0;

    const totalScore = lengthScore + uppercaseScore + digitScore + specialCharScore;
    setPasswordStrength(totalScore);

    setPassword(newPassword);

    // Check if the new password is the same as the old password
    if (newPassword === sessionStorage.getItem('oldPassword')) {
      setFormError("New password cannot be the same as the old password.");
    } else {
      setFormError('');
    }
  };

  return (
    <div className="d-flex justify-content-center align-items-center bg-secondary vh-100">
      <div className="bg-white p-3 rounded w-25">
        <h4>Reset Password</h4>
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label htmlFor="password">
              <strong>New Password</strong>
            </label>
            <input
              type="password"
              placeholder="Enter Password"
              autoComplete="off"
              name="password"
              className="form-control rounded-0"
              onChange={handlePasswordChange}
            />
          </div>
          <div className="mb-3">
            <div>
              <strong>Password Strength:</strong>
            </div>
            <div className="progress">
              <div
                className={`progress-bar bg-${getProgressBarColor(passwordStrength)}`}
                role="progressbar"
                style={{ width: `${passwordStrength * 25}%` }}
                aria-valuenow={passwordStrength * 25}
                aria-valuemin="0"
                aria-valuemax="100"
              ></div>
            </div>
          </div>
          {formError && <small className="text-danger">{formError}</small>}
          <button type="submit" className="btn btn-success w-100 rounded-0">
            Update
          </button>
        </form>
      </div>
    </div>
  );
}

const getProgressBarColor = (score) => {
  if (score < 1) {
    return 'danger';
  } else if (score < 2) {
    return 'warning';
  } else if (score < 3) {
    return 'info';
  } else {
    return 'success';
  }
};

export default ResetPassword;
