import axios from "axios";
import React, { useState } from "react";
import PhoneInput from "react-phone-number-input";
import "react-phone-number-input/style.css";
import { Link, useNavigate } from "react-router-dom";

function Signup() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [passwordStrength, setPasswordStrength] = useState("");
  const [passwordSuggestions, setPasswordSuggestions] = useState([]);
  const [usernameError, setUsernameError] = useState("");
  const [challenge, setChallenge] = useState(generateChallenge());
  const [userResponse, setUserResponse] = useState("");
  const [isCaptchaValid, setIsCaptchaValid] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [formError, setFormError] = useState("");
  const [selectedChannels, setSelectedChannels] = useState([]);
  const [contactNumber, setContactNumber] = useState("");
  const navigate = useNavigate();

  function generateChallenge() {
    const characters =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    let result = "";
    for (let i = 0; i < 6; i++) {
      result += characters.charAt(
        Math.floor(Math.random() * characters.length)
      );
    }
    return result;
  }

  const handleUsernameChange = (e) => {
    const newUsername = e.target.value;
    const usernameRegex = /^[a-zA-Z0-9_]{3,15}$/;

    if (!usernameRegex.test(newUsername)) {
      setUsernameError(
        "Username should be 3 to 15 characters long and can only contain letters, numbers, and underscores."
      );
    } else {
      setUsernameError("");
    }

    setName(newUsername);
  };

  const handlePasswordChange = (e) => {
    const newPassword = e.target.value;
    const strongRegex =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])(?=.{8,})/;
    const mediumRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.{6,})/;

    if (strongRegex.test(newPassword)) {
      setPasswordStrength("Strong");
    } else if (mediumRegex.test(newPassword)) {
      setPasswordStrength("Medium");
    } else {
      setPasswordStrength("Weak");
    }

    setPassword(newPassword);
    updatePasswordSuggestions(newPassword);
  };

  const updatePasswordSuggestions = (newPassword) => {
    const suggestions = [];

    if (newPassword.length < 6) {
      suggestions.push("Password should be at least 6 characters long.");
    }

    if (!/[a-z]/.test(newPassword)) {
      suggestions.push("Include lowercase letters.");
    }

    if (!/[A-Z]/.test(newPassword)) {
      suggestions.push("Include uppercase letters.");
    }

    if (!/[0-9]/.test(newPassword)) {
      suggestions.push("Include numbers.");
    }

    if (!/[!@#$%^&*]/.test(newPassword)) {
      suggestions.push("Include special characters (!@#$%^&*).");
    }

    setPasswordSuggestions(suggestions);
  };

  const handleChannelChange = (e) => {
    const channel = e.target.value;
    if (selectedChannels.includes(channel)) {
      setSelectedChannels(selectedChannels.filter((c) => c !== channel));
    } else {
      setSelectedChannels([...selectedChannels, channel]);
    }
  };

  const handleCaptchaChange = (e) => {
    setUserResponse(e.target.value);
  };

  const regenerateCaptcha = () => {
    setChallenge(generateChallenge());
    setIsCaptchaValid(false);
  };

  const validateCaptcha = () => {
    if (userResponse.trim() === "") {
      setIsCaptchaValid(false);
      return;
    }

    if (userResponse.toLowerCase() === challenge.toLowerCase()) {
      setIsCaptchaValid(true);
    } else {
      setIsCaptchaValid(false);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    validateCaptcha();
    if (
      !name ||
      !email ||
      !password ||
      !contactNumber ||
      !isCaptchaValid ||
      usernameError ||
      selectedChannels.length === 0
    ) {
      setFormError(
        "Please fill out all fields correctly and solve the CAPTCHA."
      );
      return;
    }

    axios
      .post("http://localhost:3002/register", {
        name,
        email,
        password,
        contactNumber,
        sportChannels: selectedChannels,
      })
      .then((res) => {
        navigate("/login");
      })
      .catch((err) => console.log(err));
  };

  return (
    <div className="flex justify-center items-center bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 min-h-screen py-6">
      <div className="bg-white p-8 rounded-lg shadow-lg max-w-lg w-full">
        <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">
          Register
        </h2>
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label htmlFor="username" className="block text-gray-700 mb-2">
              <strong>Username</strong>
            </label>
            <input
              type="text"
              placeholder="Enter Username"
              autoComplete="off"
              name="username"
              className={`form-input mt-1 block w-full ${
                usernameError ? "border-red-500" : ""
              }`}
              onChange={handleUsernameChange}
            />
            {usernameError && (
              <p className="text-red-500 text-sm mt-2">{usernameError}</p>
            )}
          </div>
          <div className="mb-4">
            <label htmlFor="email" className="block text-gray-700 mb-2">
              <strong>Email</strong>
            </label>
            <input
              type="email"
              placeholder="Enter Email"
              autoComplete="off"
              name="email"
              className="form-input mt-1 block w-full"
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div className="mb-4">
            <label htmlFor="password" className="block text-gray-700 mb-2">
              <strong>Password</strong>
            </label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                placeholder="Enter Password"
                name="password"
                className="form-input mt-1 block w-full"
                onChange={handlePasswordChange}
              />
              <button
                type="button"
                className="absolute inset-y-0 right-0 px-3 py-2 text-gray-600"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? "Hide" : "Show"}
              </button>
            </div>
            <small className="block text-gray-600 mt-2">
              Password Strength: {passwordStrength}
            </small>
            <ul className="list-disc list-inside text-red-500 mt-2">
              {passwordSuggestions.map((suggestion, index) => (
                <li key={index}>{suggestion}</li>
              ))}
            </ul>
          </div>
          <div className="mb-4">
            <label
              htmlFor="contact_number"
              className="block text-gray-700 mb-2"
            >
              <strong>Contact Number</strong>
            </label>
            <PhoneInput
              name="contactNumber"
              placeholder="Enter Contact Number"
              value={contactNumber}
              onChange={setContactNumber}
              className="form-input mt-1 block w-full"
            />
          </div>
          <div className="mb-4">
            <label htmlFor="channels" className="block text-gray-700 mb-2">
              <strong>Select Broadcast Channels</strong>
            </label>
            <div className="flex flex-wrap gap-4">
              <div>
                <input
                  type="checkbox"
                  id="football"
                  name="channels"
                  value="football"
                  onChange={handleChannelChange}
                  className="mr-2"
                />
                <label htmlFor="football">Football</label>
              </div>
              <div>
                <input
                  type="checkbox"
                  id="badminton"
                  name="channels"
                  value="badminton"
                  onChange={handleChannelChange}
                  className="mr-2"
                />
                <label htmlFor="badminton">Badminton</label>
              </div>
              <div>
                <input
                  type="checkbox"
                  id="tennis"
                  name="channels"
                  value="tennis"
                  onChange={handleChannelChange}
                  className="mr-2"
                />
                <label htmlFor="tennis">Tennis</label>
              </div>
              <div>
                <input
                  type="checkbox"
                  id="karate"
                  name="channels"
                  value="karate"
                  onChange={handleChannelChange}
                  className="mr-2"
                />
                <label htmlFor="karate">Karate</label>
              </div>
            </div>
          </div>
          <div className="mb-4">
            <label htmlFor="captcha" className="block text-gray-700 mb-2">
              <strong>Verify you're not a robot</strong>
            </label>
            <div>
              <p className="mb-2">{`Enter the following characters: ${challenge}`}</p>
              <input
                type="text"
                value={userResponse}
                onChange={handleCaptchaChange}
                className="form-input mt-1 block w-full"
              />
              <button
                type="button"
                onClick={regenerateCaptcha}
                className="mt-2 bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600 transition duration-300"
              >
                Regenerate CAPTCHA
              </button>
              {!isCaptchaValid && (
                <p className="text-red-500 text-sm mt-2">
                  Incorrect CAPTCHA solution.
                </p>
              )}
            </div>
          </div>
          {formError && (
            <p className="text-red-500 text-sm mb-4">{formError}</p>
          )}
          <button
            type="submit"
            className="bg-green-500 text-white py-2 px-4 rounded w-full hover:bg-green-600 transition duration-300"
          >
            Register
          </button>
        </form>
        <p className="mt-4 text-center">
          Already Have an Account?{" "}
          <Link to="/login" className="text-blue-500 hover:underline">
            Login
          </Link>
        </p>
      </div>
    </div>
  );
}

export default Signup;
