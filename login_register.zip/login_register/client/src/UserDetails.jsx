import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const UserDetails = () => {
  const [user, setUser] = useState(null);
  const [editing, setEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    sportChannels: [],
  });
  const navigate = useNavigate();

  useEffect(() => {
    const fetchUserDetails = async () => {
      try {
        const response = await axios.get("http://localhost:3002/user", {
          withCredentials: true,
        });
        setUser(response.data);
        setFormData({
          name: response.data.name,
          email: response.data.email,
          sportChannels: response.data.sportChannels.join(", "),
        });
      } catch (error) {
        console.error("Error fetching user details:", error);
      }
    };

    fetchUserDetails();
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleUpdate = async () => {
    try {
      await axios.put(
        "http://localhost:3002/user",
        {
          name: formData.name,
          email: formData.email,
          sportChannels: formData.sportChannels
            .split(", ")
            .map((channel) => channel.trim()),
        },
        { withCredentials: true }
      );
      setEditing(false);
      alert("User information updated successfully");
    } catch (error) {
      console.error("Error updating user details:", error);
    }
  };

  const handleLogout = () => {
    axios
      .post("http://localhost:3002/logout", {}, { withCredentials: true })
      .then(() => {
        navigate("/login");
      })
      .catch((error) => {
        console.error("Error logging out:", error);
      });
  };

  if (!user) return <div>Loading...</div>;

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center">
      <div className="bg-white p-8 rounded-lg shadow-lg max-w-md w-full mt-12">
        <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">
          User Details
        </h2>

        {editing ? (
          <>
            <div className="mb-4">
              <label htmlFor="name" className="block text-gray-700 mb-2">
                Name
              </label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                className="form-input mt-1 block w-full"
              />
            </div>
            <div className="mb-4">
              <label htmlFor="email" className="block text-gray-700 mb-2">
                Email
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                className="form-input mt-1 block w-full"
              />
            </div>
            <div className="mb-4">
              <label
                htmlFor="sportChannels"
                className="block text-gray-700 mb-2"
              >
                Sport Channels
              </label>
              <input
                type="text"
                name="sportChannels"
                value={formData.sportChannels}
                onChange={handleInputChange}
                className="form-input mt-1 block w-full"
              />
            </div>
            <button
              onClick={handleUpdate}
              className="bg-blue-500 text-white py-2 px-4 rounded w-full hover:bg-blue-600 transition duration-300"
            >
              Update
            </button>
          </>
        ) : (
          <>
            <div className="mb-4">
              <p className="text-gray-700">
                <strong>Name:</strong> {user.name}
              </p>
            </div>
            <div className="mb-4">
              <p className="text-gray-700">
                <strong>Email:</strong> {user.email}
              </p>
            </div>
            <div className="mb-4">
              <p className="text-gray-700">
                <strong>Sport Channels:</strong> {user.sportChannels.join(", ")}
              </p>
            </div>
            <button
              onClick={() => setEditing(true)}
              className="bg-yellow-500 text-white py-2 px-4 rounded w-full hover:bg-yellow-600 transition duration-300"
            >
              Edit
            </button>
          </>
        )}
        <button
          onClick={handleLogout}
          className="bg-red-500 text-white py-2 px-4 rounded w-full hover:bg-red-600 transition duration-300 mt-4"
        >
          Logout
        </button>
      </div>
    </div>
  );
};

export default UserDetails;
