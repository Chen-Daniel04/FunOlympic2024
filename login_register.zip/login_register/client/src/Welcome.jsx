import React from "react";
import { Link } from "react-router-dom";

function Welcome() {
  return (
    <div className="flex justify-center items-center bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 min-h-screen">
      <div className="bg-white p-8 rounded-lg shadow-lg max-w-sm w-full text-center">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">
          Welcome to Our Website!
        </h2>
        <p className="text-gray-600 mb-6">
          Thank you for choosing our platform. To get started, please
          <Link to="/register" className="text-blue-500 hover:underline ml-1">
            sign up here
          </Link>
          .
        </p>
        <Link
          to="/register"
          className="bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600 transition duration-300"
        >
          Get Started
        </Link>
      </div>
    </div>
  );
}

export default Welcome;
