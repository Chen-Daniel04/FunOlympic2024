export const NM_CONFIG = {
    user: 'pyiheinaung92@gmail.com',
    pass: 'vmky jllc kztp rzfq'
}