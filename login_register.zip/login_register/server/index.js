import express from "express";
import mongoose from "mongoose";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import cors from "cors";
import cookieParser from "cookie-parser";
import nodemailer from "nodemailer";
import qrcode from "qrcode";
import speakeasy from "speakeasy";
import { NM_CONFIG } from "./config.js";
import connectToDB from "./db/conn.js";
import ChannelModel from "./models/Channel.js";
import UserModel from "./models/User.js";

const app = express();
connectToDB();

app.use(express.json());
app.use(cookieParser());
app.use(cors({ origin: true, credentials: true }));

const secretKey = "ji11221jlkejakljasd";

const transporter = nodemailer.createTransport({
	service: "gmail",
	auth: NM_CONFIG,
});

const checkPasswordChangeLimit = async (req, res, next) => {
	const { email, newpassword } = req.body;

	try {
		const user = await UserModel.findOne({ email });

		if (user) {
			if (
				(await bcrypt.compare(newpassword, user.password)) ||
				(await bcrypt.compare(newpassword, user.password))
			) {
				return res.status(400).json({
					error: "New password cannot be the same as the old password.",
				});
			}

			if (!Array.isArray(user.passwordChangeDates)) {
				user.passwordChangeDates = [];
			}

			const todayString = new Date().toISOString().split("T")[0];

			const changesToday = user.passwordChangeDates.filter((date) => {
				const changeDateString = new Date(date).toISOString().split("T")[0];
				return changeDateString === todayString;
			});

			if (changesToday.length >= 2) {
				return res
					.status(400)
					.json({ error: "Password can only be changed twice a day." });
			}
		}

		next();
	} catch (error) {
		console.error(error);
		res.status(500).json({ error: "Internal Server Error" });
	}
};

const verifyUser = (req, res, next) => {
	const token = req.cookies.token;
	if (!token) {
		return res.status(401).json({ error: "Token is missing" });
	}
	jwt.verify(token, "jwt-secret-key", (err, decoded) => {
		if (err) {
			return res.status(401).json({ error: "Error with token" });
		}
		req.user = decoded; // Attach user info to request object
		next();
	});
};

app.get("/dashboard", verifyUser, (req, res) => {
	res.json("Success");
});

app.post("/register", async (req, res) => {
	try {
		const { name, email, password, contactNumber, sportChannels } = req.body;
		const secret = speakeasy.generateSecret({ length: 20 });
		const hash = await bcrypt.hash(password, 10);
		const user = await UserModel.create({
			name,
			email,
			password: hash,
			contactNumber,
			secretKey: secret,
			sportChannels,
		});
		res.json({ Status: "Success" });
	} catch (err) {
		res.status(400).json({ error: err.message });
	}
});

app.post("/login", (req, res) => {
	const { email, password } = req.body;
	UserModel.findOne({ email })
		.then((user) => {
			if (user) {
				bcrypt.compare(password, user.password, (err, response) => {
					if (response) {
						const token = jwt.sign(
							{ email: user.email, role: user.role, id: user._id },
							"jwt-secret-key", // Use environment variable
							{ expiresIn: "1d" },
						);
						res.cookie("token", token, { httpOnly: true, secure: false }); // Ensure secure flag is used in production
						return res.json({ Status: "Success", role: user.role });
					}
					return res.status(401).json({ error: "The password is incorrect" });
				});
			} else {
				return res.status(404).json({ error: "No record existed" });
			}
		})
		.catch((err) => res.status(500).json({ error: "Internal Server Error" }));
});

app.get("/check-auth", (req, res) => {
	const token = req.cookies.token;
	if (!token) {
		return res.status(401).json({ isAuthenticated: false });
	}
	jwt.verify(token, "jwt-secret-key", (err, decoded) => {
		// Use the same secret key
		if (err) {
			return res.status(401).json({ isAuthenticated: false });
		}
		return res.status(200).json({ isAuthenticated: true });
	});
});

app.post("/forgot-password", (req, res) => {
	const { email } = req.body;
	UserModel.findOne({ email })
		.then((user) => {
			if (!user) {
				return res.status(404).json({ Status: "User not existed" });
			}

			const token = jwt.sign({ id: user._id }, "jwt_secret_key", {
				expiresIn: "1d",
			});

			const mailOptions = {
				from: "pyiheinaung92@gmail.com",
				to: user.email,
				subject: "Reset Password Link",
				text: `http://localhost:5173/reset-password/${user._id}/${token}`,
			};

			transporter.sendMail(mailOptions, (error, info) => {
				if (error) {
					console.log(error);
					return res.status(500).json({ error: "Internal Server Error" });
				}
				return res.json({ Status: "Success" });
			});
		})
		.catch((err) => res.status(500).json({ error: "Internal Server Error" }));
});

app.post("/reset-password/:id/:token", checkPasswordChangeLimit, (req, res) => {
	const { id, token } = req.params;
	const { password } = req.body;

	jwt.verify(token, "jwt_secret_key", async (err, decoded) => {
		if (err) {
			return res.status(401).json({ Status: "Token verification failed" });
		}
		if (decoded.id === id) {
			const newhash = await bcrypt.hash(password, 10);

			try {
				const user = await UserModel.findById(id);

				if (user) {
					if (await bcrypt.compare(password, user.password)) {
						return res.status(400).json({
							error: "New password cannot be the same as the old password.",
						});
					}

					await UserModel.findByIdAndUpdate(id, {
						password: newhash,
						$push: { passwordChangeDates: new Date() },
						lastPassword: user.password,
					});

					return res.json({ Status: "Success" });
				}
				return res.status(404).json({ error: "User not found" });
			} catch (error) {
				console.error(error);
				return res.status(500).json({ error: "Internal Server Error" });
			}
		} else {
			return res.status(400).json({ Status: "Invalid user ID" });
		}
	});
});

app.post("/generate-qr", (req, res) => {
	const { email } = req.body;

	UserModel.findOne({ email })
		.then((user) => {
			if (!user) {
				return res.status(404).send("User not found");
			}

			const secretKey = user.secretKey;

			qrcode.toDataURL(secretKey.otpauth_url, (err, imageUrl) => {
				if (err) {
					console.log("Error generating QR code", err);
					return;
				}
				res.status(200).json({ qrURL: imageUrl });
			});
		})
		.catch((error) => {
			console.log("Error finding user", error);
			res.status(500).send("Failed to find user");
		});
});

app.post("/verify-qr", (req, res) => {
	const { email, token } = req.body;

	UserModel.findOne({ email })
		.then((user) => {
			if (!user) {
				return res.status(404).send("User not found");
			}

			const secretKey = user.secretKey;

			const verified = speakeasy.totp.verify({
				secret: secretKey.base32,
				encoding: "base32",
				token,
				window: 1,
			});

			if (verified) {
				res.status(200).json({ verified: true });
			} else {
				res.status(401).send("OTP Verification failed!");
			}
		})
		.catch((error) => {
			console.log("Error finding user", error);
			res.status(500).send("Failed to find user");
		});
});

app.post("/get-otp", (req, res) => {
	const { email } = req.body;
	const otp = generateRandomNumber();

	UserModel.findOneAndUpdate({ email }, { otp }, { new: true })
		.then((user) => {
			if (!user) {
				return res.status(404).send("User not found");
			}

			const mailOptions = {
				from: NM_CONFIG.user,
				to: email,
				subject: "OTP Verification",
				text: `Your OTP is: ${otp}`,
			};

			transporter.sendMail(mailOptions, (error, info) => {
				if (error) {
					console.log("Error sending OTP", error);
					res.status(500).send("Failed to send OTP");
				} else {
					console.log("OTP sent successfully", info.response);
					res.send("OTP sent successfully");
				}
			});
		})
		.catch((error) => {
			console.log("Error finding user", error);
			res.status(500).send("Failed to find user");
		});
});

app.post("/verify-otp", (req, res) => {
	const { email, otp } = req.body;

	UserModel.findOne({ email })
		.then((user) => {
			if (!user) {
				return res.status(404).send("User not found");
			}
			if (user.otp !== otp) {
				return res.status(401).send("OTP Verification failed!");
			}

			console.log("OTP matched");

			res.status(200).json({ verified: true });
		})
		.catch((error) => {
			console.log("Error finding user", error);
			res.status(500).send("Failed to find user");
		});
});

app.post("/change-password", checkPasswordChangeLimit, async (req, res) => {
	const { email, password, newpassword } = req.body;
	const newhash = await bcrypt.hash(newpassword, 10);

	try {
		const user = await UserModel.findOne({ email });

		if (user) {
			const isPasswordCorrect = await bcrypt.compare(password, user.password);

			if (isPasswordCorrect) {
				await UserModel.findOneAndUpdate(
					{ email },
					{
						password: newhash,
						$push: { passwordChangeDates: new Date() },
						lastPassword: user.password,
					},
				);
				return res.json({ Status: "Success" });
			}
			return res
				.status(401)
				.json({ error: "The current password is incorrect" });
		}
		return res
			.status(404)
			.json({ error: "No record existed for the given email" });
	} catch (error) {
		console.error(error);
		return res.status(500).json({ error: "Internal Server Error" });
	}
});

app.post("/increase-visitor-count", async (req, res) => {
	const { channel } = req.body;

	if (!channel) {
		return res.status(400).json({ error: "Channel name is required" });
	}

	try {
		let channelDoc = await ChannelModel.findOne({ name: channel });

		if (channelDoc) {
			channelDoc.visitorCount += 1;
			await channelDoc.save();
		} else {
			channelDoc = new ChannelModel({ name: channel, visitorCount: 1 });
			await channelDoc.save();
		}

		res.json({ Status: "Success", visitorCount: channelDoc.visitorCount });
	} catch (error) {
		console.error(error);
		res.status(500).json({ error: "Internal Server Error" });
	}
});

app.get("/channels", async (req, res) => {
	try {
		const channels = await ChannelModel.find({});
		res.json({ Status: "Success", channels });
	} catch (error) {
		console.error(error);
		res.status(500).json({ error: "Internal Server Error" });
	}
});

app.get("/users", verifyUser, async (req, res) => {
	try {
		const users = await UserModel.find({}, "name email role sportChannels");
		res.json(users);
	} catch (error) {
		console.error(error);
		res.status(500).json({ error: "Internal Server Error" });
	}
});

app.get("/user", verifyUser, async (req, res) => {
	try {
		const user = await UserModel.findById(req.user.id, "name email sportChannels");
		console.log(user)
		if (!user) {
			return res.status(404).json({ error: "User not found" });
		}
		res.json(user);
	} catch (error) {
		console.error(error);
		res.status(500).json({ error: "Internal Server Error" });
	}
});

app.get("/check-auth", (req, res) => {
	const token = req.cookies.token;
	if (!token) {
		return res.json({ isAuthenticated: false });
	}
	jwt.verify(token, "jwt-secret-key", (err) => {
		if (err) {
			return res.json({ isAuthenticated: false });
		}
		return res.json({ isAuthenticated: true });
	});
});

app.put("/user", verifyUser, async (req, res) => {
	try {
		const { name, email, sportChannels } = req.body;
		const user = await UserModel.findByIdAndUpdate(
			req.user.id,
			{ name, email, sportChannels },
			{ new: true }
		);
		if (!user) {
			return res.status(404).json({ error: "User not found" });
		}
		res.json(user);
	} catch (error) {
		console.error(error);
		res.status(500).json({ error: "Internal Server Error" });
	}
});

// Update user
app.put("/users/:id", verifyUser, async (req, res) => {
	try {
		const { id } = req.params;
		const { name, email, role } = req.body;
		const user = await UserModel.findByIdAndUpdate(id, { name, email, role }, { new: true });
		if (!user) {
			return res.status(404).json({ error: "User not found" });
		}
		res.json({ Status: "Success", user });
	} catch (error) {
		console.error(error);
		res.status(500).json({ error: "Internal Server Error" });
	}
});

// Delete user
app.delete("/users/:id", verifyUser, async (req, res) => {
	try {
		const { id } = req.params;
		const user = await UserModel.findByIdAndDelete(id);
		if (!user) {
			return res.status(404).json({ error: "User not found" });
		}
		res.json({ Status: "Success" });
	} catch (error) {
		console.error(error);
		res.status(500).json({ error: "Internal Server Error" });
	}
});

// Reset password
app.post("/users/:id/reset-password", verifyUser, async (req, res) => {
	try {
		const { id } = req.params;
		const { newPassword } = req.body;
		const hash = await bcrypt.hash(newPassword, 10);
		const user = await UserModel.findByIdAndUpdate(id, { password: hash }, { new: true });
		if (!user) {
			return res.status(404).json({ error: "User not found" });
		}
		res.json({ Status: "Success" });
	} catch (error) {
		console.error(error);
		res.status(500).json({ error: "Internal Server Error" });
	}
});

function generateRandomNumber() {
	const min = 100000;
	const max = 999999;
	return Math.floor(Math.random() * (max - min + 1)) + min;
}

const PORT = process.env.PORT || 3002;
app.listen(PORT, () => {
	console.log(`Server is running on port ${PORT}`);
});
