import mongoose from 'mongoose';

const { Schema } = mongoose;

const channelSchema = new Schema({
    name: {
        type: String,
        required: true,
    },
    visitorCount: {
        type: Number,
        default: 0,
    }
});

const ChannelModel = mongoose.model('Channel', channelSchema);
export default ChannelModel;


