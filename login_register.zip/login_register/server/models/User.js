import mongoose from 'mongoose';

const { Schema } = mongoose;

const userSchema = new Schema({
  name: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
    match: /^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/,
  },
  password: {
    type: String,
    required: true,
  },
  contactNumber: {
    type: String,
    required: true
  },
  role: {
    type: String,
    default: 'visitor',
    enum: ['visitor', 'admin'], // Add other roles as needed
  },
  otp: {
    type: String,
    default: '',
  },
  secretKey: {
    type: Object,
    default: {},
  },
  sportChannels: [{
    type: String,
    enum: ['football', 'badminton', 'tennis', 'karate'],
  }],
});

const UserModel = mongoose.model('User', userSchema);
export default UserModel;


